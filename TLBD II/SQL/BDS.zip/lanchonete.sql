CREATE DATABASE DB_LANCHONETE;

SHOW DATABASES;

USE DB_LANCHONETE; 

CREATE TABLE categoria
(
	id INT PRIMARY KEY,
    nome VARCHAR(30)
   
);

CREATE TABLE produto(
	id INT NOT NULL,
    nome VARCHAR(30) NOT NULL,
    preco FLOAT NOT NULL,
	quantidade INT,
    id_categoria INT NOT NULL,
    PRIMARY KEY (id),
    FOREIGN KEY (id_categoria) REFERENCES categoria(id) /*chave estrangeira*/
);

INSERT INTO categoria(id, nome)
VALUES(01, 'lanche simples'),
	  (02, 'lanche complexo'),
      (03, 'salgado'),
      (04, 'doce'),
      (05, 'bebida');
      
INSERT INTO produto(id, nome, preco, quantidade, id_categoria)
VALUES(011, 'hamburguer', 25.00, 1000, 03),
	  (022, 'chesseburguer', 29.00, 2000, 01),
      (033, 'x-tudo', 35.00, 3000, 02),
      (044, 'coca cola', 6.00, 4000, 05),
      (055, 'paçocão', 2.50, 5000, 04);
      

/*DROP DATABASE DB_LANCHONETE /* APAGA O BANCO DE DADOS */