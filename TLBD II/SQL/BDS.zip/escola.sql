create database BD_ESCOLA;
use BD_ESCOLA;

create table Curso(
cod int not null,
nome varchar(50) not null,
cargaHora int not null,
dataInicio int not null,
Horario varchar(150),
lugar varchar (150) not null,
valor double not null,
primary key (cod)
); 

create table professor(
cod int not null,
nome varchar (100),
endereco varchar (150),
fone_professor int,
primary key (cod)
);

create table aluno(
cod int not null,
nome varchar (100),
endereco varchar(150),
fone_aluno int,
frequencia int,
nota double,
primary key (cod),
foreign key (fone_aluno) references fone_aluno
);

create table fone_prof(
fone int not null, 
cod_professor int not null,
foreign key (cod_professor) references professor(cod),
primary key (cod, fone)
);

create table fone_aluno(
fone int not null,
cod int not null,
primary key (fone),
foreign key (cod) references aluno
);

insert into Curso(cod,nome,cargaHora,dataInicio,horario,lugar,valor)
values  (258,'X',450,14072012,'Unesp',5199.99),
		(259,'Y',500,04052006,'Usp',5201),
        (260,'Z',800,20012078,'Unicamp',26350.00);
      
 insert into professor(cod,nome,endereco,fone_professor)
 values (295125402,'Jeff','Verdelandia',325122145),
		(471825285,'Loki','Asgard ',25252518),
        (562555544,'Pyga','Floresta Verde',317958400);
   
 insert into aluno(cod,nome,endereco,fone_aluno,frequencia,nota) 
 values (45972,'Mojhgg','rua hsfsaud n0528',100,6.54),
		(52525,'Lysa','rua jahdshd n587',50,5.77),
        (53140,'Nhe Humm','rua kujgrd',77,8.58);
        
/*Consulta*/
select cod, nome, nota from aluno;
select cod, nome, valor from Curso;
select * from professor;




