create database diatrintaeum;

use diatrintaeum;

CREATE TABLE departamento
(
idDepto SMALLINT UNSIGNED NOT NULL
		AUTO_INCREMENT,
nomeD VARCHAR(50) NOT NULL,
atuacao VARCHAR(30),
CONSTRAINT pk_depto PRIMARY KEY (idDepto)
);

CREATE TABLE funcionario (
idFunc SMALLINT UNSIGNED NOT NULL AUTO_INCREMENT,
nomeF VARCHAR(50) NOT NULL,
emailF VARCHAR(50) NOT NULL, 
sexoF ENUM('M', 'F'),
nascF DATE,
idDepto SMALLINT UNSIGNED NOT NULL,
CONSTRAINT pk_func PRIMARY KEY(idFunc),
CONSTRAINT fk_func_depto FOREIGN KEY (idDepto)
						 REFERENCES departamento (idDepto)
						 ON DELETE CASCADE
);

insert into departamento (idDepto,nomeD,atuacao)
	values	(null,'Engenharia',1),
			(null,'RH',        3),
            (null,'Estoque',   2);
            
insert into funcionario (idFunc,nomeF,emailF,sexoF,nascF,idDepto)
	values	(null,'Isidro',      'isidro@ts.com.br', 'M','2010-01-01',1),
			(null,'Sezefredo',   'sz@ts.com.br',     'M','2010-01-01',1),
            (null,'Adamastor',   'ad@ts.com.br',     'M','2010-01-01',1),
            (null,'Deosdedite',  'dd@ts.com.br',     'M','2010-01-01',1),
            (null,'Energarda',   'en@ts.com.br',     'F','2010-01-01',2),
            (null,'Josicleide',  'josi@ts.com.br',   'F','2010-01-01',2),
            (null,'Nilsoncleide','ns@ts.com.br',     'M','2010-01-01',3),
            (null,'Roberval',    'rb@ts.com.br',     'M','2010-01-01',3);
            
select * from departamento;

select count(idDepto) from departamento;

select COUNT(idFunc) from funcionario; 			/*count() contar*/

select count(*) from departamento;

Select nomeF from funcionario where emailF not like '@empr.com.br';                                                                                          

                        

