create database BD_AGRO;   
use BD_AGRO;


create table fazenda(
cod int not null,  
nome char(100) not null,
tamanho double not null,
localizacao varchar(100),
primary key(cod) 
);

create table fone_prop(
fone_prop int not null,
cod_prop int not null,
primary key (fone_prop),
foreign key (cod_prop) references proprietario
);

create table proprietario(
cod int not null,
nome varchar(100),
endereco varchar(150),
fone int not null,
primary key (cod),
foreign key (fone) references fone_prop 
);
create table fa_prop(
cod_prop int not null,
cod_fazen int not null,
foreign key (cod_fazen) references fazenda (cod), 
foreign key (cod_prop) references proprietario (cod), 
primary key (cod_prop,cod_fazen)
);

create table produto(
cod int not null,
primary key(cod),
nome char(100) not null, 
descric varchar(200),
tempoDeVida int not null
);
 
create table pragas(
cod int not null,
nomePop varchar(50),
nomeCient varchar (100) not null,
primary key(cod),
tempoDeVida int not null
);

create table defensivoBio(
nomeCientifico varchar(100) not null,
cod int not null,
primary key (cod) 
);

create table defensivoQuimi(
cod int not null,
primary key (cod),
volume double,
prazoVida int not null,
descricaoComponentes varchar(700),
efeitosColaterais varchar (600)
);

insert into fazenda(cod,nome,tamanho,localizacao)
		values(001,'Fae',500,'Artemis - SP'),
			  (002,'Sau',500,'Embu das Artes - SP'),
			  (003,'Fel',500,'Wenceslau Braz - MG');
       
insert into proprietario (cod,nome,endereco,fone)
		values(002,'Jayne','Crisolita',25014708),
			  (003, 'Tony','Delta',92415781),
              (004,'Spike','Espera Feliz',35264105);
   insert into fone_prop(fone_prop,cod_prop) 
   values      	(002,25014708),
				(003,92415781),
                (004,35264105);
 
insert into produto(cod,nome,descri,tempoVida) 
       values(006,'Maça','fruta',4),
			 (007,'pera','fruta',6),
             (008,'batata','tuberculo',2);
             
insert into pragas(cod,nomePop,nomeCient)
		values(009,'Cupim','cupys'),
			  (010,'formiga','hormygus'),
			  (011,'Abelha','abelhys');
          
insert into defensivoBio(nomeCientifico,cod)
		values('Lguvuy',120),
		      ('Sxciybl',500),
			  ('Diutym',458);
        
insert into defensivoQuimi(cod,volume,prazoVida,descriçaoComponentes,efeitosColaterais)
		values	(520,847,85,'A','B'),     
				(582,987,10,'C','T'),
				(540,45,12,'M','L');
        

/*consulta */
     
Select localizacao, tamanho from fazenda;
select * from produto; 
select cod, prazoVida from defensivoQuimi;