create database BD_AGRO; /*ASSUNTO: 2EMINFO  
							AVALIAÇÃO 1
                            CORPO: nome1, nome2*/
use BD_AGRO;
create table Fazenda(
cod int not null,  
nome char(100) not null,
tamanho double not null,
localização varchar(100),
primary key(cod) 
);

create table proprietario(
cod int not null,
nome char(100),
endereco varchar(150),
fone int not null,
primary key (cod)
);
create table fone_prop(
primary key (fone_prop),
foreign key (cod_prop) references proprietario
);
create table produto(
cod int not null,
primary key(cod),
nome char(100) not null, 
descric varchar(200),
tempoDeVida int not null
); 
create table pragas(
cod int not null,
nomePop varchar(50),
nomeCient varchar (100) not null,
primary key(cod),
tempoDeVida int not null
);
create table defensivoBio(
nomeCientifico varchar(100) not null,
cod int not null,
primary key (cod) 
);
create table defensivoQuimi(
cod  int not null,
primary key (cod),
volume double,
prazoVida int not null,
descricaoComponentes varchar(700),
efeitosColaterais varchar (600)
);

insert into fazenda(cod,nome,tamanho,localização)
values (001,'Alegria',500,'Mogi Mirim'),
	   (002,'Saude',500,'Mogi Mirim'),
       (003,'Felicidade',500,'Mogi Mirim');
       
insert into proprietario (fone_prop,cod)
       values(35622415,002),
			 (52418527,003),
             (25493403,004);
 
insert into produto(cod,nome,descri,tempoVida) 
       values(006,'Maça','fruta',4),
			 (007,'pera','fruta',6),
             (008,'batata','tuberculo',2);
             
insert into pragas(cod,nomePop,nomeCient)
	values(009,'Cupim','cupys'),
	      (010,'formiga','hormygus'),
          (011,'Abelha','abelhys');
          
insert into defensivoBio(nomeCientifico,cod)
values  ('lkyuags',120),
		('lyares',500),
		('oiyts',458);
        
insert into defensivoQuimi(cod,volume,prazoVida,descriçaoComponentes,efeitosColaterais)
values	(520,847,85,'A','B'),     
		(582,987,10,'C','T'),
        (540,45,12,'M','L');
        

     
create database BD_ESCOLA;
use BD_ESCOLA;

create table Curso(
cod int not null,
nome varchar(50) not null,
cargaHora int not null,
dataInicio int not null,
Horario varchar(150),
lugar varchar (150) not null,
valor double not null,
primary key (cod)
);
create table professor(
cod int not null,
nome varchar (100),
endereco varchar (150),
fone_professor int,
primary key (cod)
);
create table aluno(
cod int not null,
nome varchar (100),
endereco varchar(150),
fone_aluno int,
frequencia int,
nota double,
primary key (cod)
);
create table fone_prof(
fone int, 
primary key (fone),
foreign key (cod) references professor
);
create table fone_aluno(
fone int not null,
primary key (fone),
foreign key (cod) references aluno
);

insert into Curso(cod,nome,cargaHora,dataInicio,horario,lugar,valor)
values  (258,'X',450,14072012,'Unesp',5199.99),
		(259,'Y',500,04052006,'Usp',5201),
        (260,'Z',800,20012078,'Unicamp',26350.00);
      
 insert into professor(cod,nome,endereco,fone_professor)
 values (295125402,'Jeff','POO',325122145),
		(471825285,'Lokigt','ljhyhbgfd',25252518),
        (562555544,'Pyga','fjddqa',317958400);
   
 insert into aluno(cod,nome,endereco,fone_aluno,frequencia,nota) 
 values (45972,'Mojhgg','rua hsfsaud n0528',100,6.54),
		(52525,'Lysa','rua jahdshd n587',50,5.77),
        (53140,'Nhe Humm','rua kujgrd',77,8.58);
        




